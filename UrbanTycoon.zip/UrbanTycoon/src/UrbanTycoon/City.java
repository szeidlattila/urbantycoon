/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UrbanTycoon;

import java.util.ArrayList;

/**
 *
 * @author Felhasználó
 */
class City {
    private ArrayList<Resident> residents;
    private Field[][] fields;
    private int satisfaction;
    private int criticalSatisfaction;
    private long budget;
    private int negativeBudgetNthYear = 0;
    private long income;
    private long outgo;
    
    public City(int residentsNum, int fieldSize, int fieldRowsNum, int fieldColsNum, int criticalSatisfaction, int budget){
        
    }
    
    public ArrayList<Resident> getResidents(){
        return residents;
    }
    
    public int getResidentsNum(){
        return residents.size();
    }
    
    public Field[][] getFields(){
        return fields;
    }
    
    public int getSatisfaction(){
        return satisfaction;
    }
    
    public int getCriticalSatisfaction(){
        return criticalSatisfaction;
    }
    
    public long getBudget(){
        return budget;
    }
    
    public int negativeBudgetNthYear(){
        return negativeBudgetNthYear;
    }
    
    public long getIncome(){
        return income;
    }
    
    public long getOutgo(){
        return outgo;
    }
    
    public void setBudget(long budget){
        this.budget = budget;
    }
    
    public void setNegativeBudgetNthYear(int n){
        negativeBudgetNthYear = n;
    }
    
    public void setIncome(long income){
        this.income = income;
    }
    
    public void setOutgo(long outgo){
        this.outgo = outgo;
    }
    
    public void addResident(Resident resident){
        
    }
    
    public void removeResident(Resident resident){
        
    }

    public boolean isSatisfactionCritical(){
        
    }
    
    public void changeSatisfaction(){
        
    }
    
    public void draw(){
        
    }
}

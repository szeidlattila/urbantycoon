/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UrbanTycoon;

/**
 *
 * @author Felhasználó
 */
class Date {
    private int year,month,day,hour,minute;

    public Date(int year, int month, int day, int hour, int minute) {
        this.year = year;
        this.month = month;
        this.day = day;
        this.hour = hour;
        this.minute = minute;
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public int getDay() {
        return day;
    }

    public int getHour() {
        return hour;
    }

    public int getMinute() {
        return minute;
    }
    
    public void nMinutesElapsed(int n){
        minute += n;
        if(minute>59){minute -= 59; nHoursElapsed(1);}
    }
    
    public void nHoursElapsed(int n){
        hour += n;
        if(hour>23){hour -= 24; nDaysElapsed(1);}
    }
    
    public void nDaysElapsed(int n){
        day += n;
        if...
    }
    public void nMonthsElapsed(int n){
        month += n;
        if(month > 12){month -= 12; year++;}
    }
}

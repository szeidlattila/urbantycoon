/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UrbanTycoon;

import java.awt.Image;

/**
 *
 * @author Felhasználó
 */
abstract class Zone extends Buildable{
    protected final int capacity;
    protected int peopleNum;
    protected int safety;
    protected int selectPrice;
    protected int annualTax;
    protected double refund;
    protected boolean builtUp;
    protected boolean isOnFire = false;
    protected double chanceOfFire;
    protected Zone(int capacity, int annualTax, double refund, double chanceOfFire,int x,int y,int width, int height,Image image){
        super(x,y,width,height,image);
        this.capacity = capacity;
        this.annualTax = annualTax;
        this.refund = refund;
    }

    public void setAnnualTax(int annualTax) {
        this.annualTax = annualTax;
    }
    
    @Override
    public int getAnnualTax() {
        return annualTax;
    }
    
    protected void destroy(){
        if(builtUp) return;
    }
    
    public void fireSpread(){
        
    }
    
    public void burnsDown(){
        
    }
}

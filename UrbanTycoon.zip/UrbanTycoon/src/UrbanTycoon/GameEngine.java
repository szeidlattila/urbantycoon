/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UrbanTycoon;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPanel;
import javax.swing.Timer;

/**
 *
 * @author Felhasználó
 */
class GameEngine extends JPanel{
    
    private final int FPS = 240;
    private final int FIELDSIZE; //TODO
    private final int FIELDROWSNUM;
    private final int FIELDCOLSNUM;
    private final int INITIALMONEY;
    private final int INITIALRESIDENT;
    private final int ZONEPRICE;
    private final int RESIDENTCAPACITY;
    private final int WORKPLACECAPACITY;
    private final double REFUND;
    private final int RADIUS;
    private final int CRITSATISFACTION = -5;
    
    
    private final City city;
    private Date time;
    private boolean paused;
    private int speed = 0;
    private Image background;
    private Timer newFrameTimer = new Timer(1/FPS,new NewFrameListener());
    
//----------------------------
    //fv-ek
//-----------------------------
    
    public GameEngine(){
        
    }
    
    @Override
    protected void paintComponent(Graphics grphcs){
        
    }
    
    private void newGame(){
        
    }
    
    private void saveGame(){
        
    }
    
    private void loadGame(){
        
    }
    
    private void speedUpTime(){
        
    }
    
    private void slowDownTime(){
        
    }
    
    private void togglePause(){
        
    }
    class NewFrameListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            
            repaint();
        }
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UrbanTycoon;

import java.awt.Image;

/**
 *
 * @author Felhasználó
 */
public abstract class PlayerBuildIt extends Buildable{
    protected int buildingPrice;
    protected int annualFee;
    protected PlayerBuildIt(int buildingPrice, int annualFee,int x,int y,int width, int height,Image image){
        super(x,y,width,height,image);
        this.buildingPrice = buildingPrice;
        this.annualFee = annualFee;
    }

    public int getBuildingPrice() {
        return buildingPrice;
    }
    
    @Override
    public int getAnnualFee() {
        return annualFee;
    }
}

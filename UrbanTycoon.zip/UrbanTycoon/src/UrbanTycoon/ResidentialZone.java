/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UrbanTycoon;

import java.awt.Image;

/**
 *
 * @author Felhasználó
 */
class ResidentialZone extends Zone{
    double moveInChance = 0.0;
    public ResidentialZone(double moveInChance,int capacity, int annualTax, double refund, double chanceOfFire,int x,int y,int width, int height,Image image){
        super(capacity,annualTax,refund,chanceOfFire,x,y,width,height,image);
        this.moveInChance = moveInChance;
    }

    public void setMoveInChance(double moveInChance) {
        this.moveInChance = moveInChance;
    }

    public double getMoveInChance() {
        return moveInChance;
    }
    
}

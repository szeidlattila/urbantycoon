/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UrbanTycoon;

/**
 *
 * @author Felhasználó
 */
class Resident {
    private int age;
    private boolean retired=false;
    private double chanceOfDeath = 0.0;
    private int satisfaction;
    private ResidentialZone home;
    private Workplace workplace;
    private long paidTaxesInLast20YearBeforeRetired;
    
    public Resident(int age, ResidentialZone home, Workplace workplace){
        
    }
    
    public int getAge(){
        return age;
    }
    
    public boolean isRetired(){
        return age>=65;
    }
    
    public double getChanceOfDeath(){
        return chanceOfDeath;
    }
    
    public int getSatisfaction(){
        return satisfaction;
    }
    
    public ResidentialZone getHome(){
        return home;
    }
    
    public Workplace getWorkplace(){
        return workplace;
    }
    
    public void increaseAge(){
        
    }
    
    public void increaseSatisfaction(){
        
    }
    
    public void decreaseSatisfaction(){
        
    }
    
    public void setHome(ResidentialZone home){
        this.home=home;
    }
    
    public void setWorkplace(Workplace workplace){
        this.workplace = workplace;
    }
    
    private void movesAwayFromCity(){
        
    }
    
    public void changeSatisfaction(){
        
    }
    
    public void retire(){
        
    }
    
    public void die(){
        
    }
}
